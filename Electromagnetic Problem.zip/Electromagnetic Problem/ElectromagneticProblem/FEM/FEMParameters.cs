﻿namespace ElectromagneticProblem.FEM
{
	class FEMParameters
	{
		public static int BasisSize = 4;
		public static int ElementVerticesCount = 4;
	}
}
