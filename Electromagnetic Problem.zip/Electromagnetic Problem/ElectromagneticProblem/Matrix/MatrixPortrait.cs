﻿
namespace ElectromagneticProblem.Matrix
{
	public class MatrixPortrait
	{
		public int[] IA { get; set; } = null;
		public int[] JA { get; set; } = null;
	}
}
